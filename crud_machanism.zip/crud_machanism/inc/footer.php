	</div>
	
    <div class="jumbotron text-center text-uppercase">
    	<span>&copy; 2021 all files reserved.</span>
      <h2>www.musabmahmud.com</h2>
    </div>
</body>
</html>